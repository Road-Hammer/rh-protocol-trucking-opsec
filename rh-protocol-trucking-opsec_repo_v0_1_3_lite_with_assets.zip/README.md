

**Note:** This is the LITE repo (no print assets). After creating the GitHub repo, upload the PDF cards as **Release assets** or share them separately.


**Included:** Lightweight print cards in `print_assets/` (GitHub-safe). For high-res/locked versions, distribute separately as a ZIP or external link.
